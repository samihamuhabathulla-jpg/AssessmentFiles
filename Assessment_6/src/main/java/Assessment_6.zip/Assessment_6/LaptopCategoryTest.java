package Assessment_6;

import java.time.Duration;
import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LaptopCategoryTest {

    public static void main(String[] args) {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        driver.get("https://www.demoblaze.com/index.html");

        wait.until(ExpectedConditions.elementToBeClickable(By.id("login2"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginusername"))).sendKeys("samihaM");
        driver.findElement(By.id("loginpassword")).sendKeys("2005");
        driver.findElement(By.xpath("//button[text()='Log in']")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("nameoftheuser")));

        wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Laptops"))).click();

        By productLocator = By.xpath("//h4[@class='card-title']/a");
        wait.until(ExpectedConditions.visibilityOfElementLocated(productLocator));

        List<WebElement> products = driver.findElements(productLocator);
        if (products.size() == 0) {
            wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(productLocator, 0));
            products = driver.findElements(productLocator);
        }

        Set<String> laptopSet = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

        for (WebElement p : products) {
            String name = p.getText().trim();
            if (!name.isEmpty()) {
                laptopSet.add(name);
            }
        }

        
        System.out.println("Sorted Laptop List:");
        for (String name : laptopSet) {
            System.out.println("Found Laptop: " + name);
        }

        WebElement macbook = wait.until(
                ExpectedConditions.elementToBeClickable(By.linkText("MacBook Pro"))
        );

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", macbook);

        String productTitle = macbook.getText();
        System.out.println("Selected Laptop: " + productTitle);

        driver.quit();
    }
}