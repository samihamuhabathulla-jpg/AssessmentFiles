package com.assessment3;

import java.util.Scanner;

class BankException extends Exception {
    int code;

    BankException(String msg, int code) {
        super(msg);
        this.code = code;
    }
}

class InvalidAccountException extends BankException {
    InvalidAccountException(String msg, int code) {
        super(msg, code);
    }
}

class InsufficientFundsException extends BankException {
    InsufficientFundsException(String msg, int code) {
        super(msg, code);
    }
}

class TransactionLimitException extends BankException {
    TransactionLimitException(String msg, int code) {
        super(msg, code);
    }
}

public class BankingMainApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Account ID:");
        String accId = sc.nextLine();

        System.out.println("Enter Balance:");
        double balance = sc.nextDouble();

        System.out.println("Enter Amount:");
        double amount = sc.nextDouble();

        System.out.println("Enter Daily Limit:");
        double limit = sc.nextDouble();

        checkTransaction(accId, balance, amount, limit);

        sc.close();
    }

    public static void checkTransaction(String accId, double balance, double amount, double limit) {

        try {
            if (accId.equals("")) {
                throw new InvalidAccountException("Account ID empty", 1001);
            }

            if (balance < amount) {
                throw new InsufficientFundsException("Not enough balance", 1002);
            }

            if (amount > limit) {
                throw new TransactionLimitException("Limit exceeded", 1003);
            }

            System.out.println("Transaction Success");

        } catch (BankException e) {
            System.out.println(e.getMessage() + " Code: " + e.code);
        }

        System.out.println("Done");
    }
}