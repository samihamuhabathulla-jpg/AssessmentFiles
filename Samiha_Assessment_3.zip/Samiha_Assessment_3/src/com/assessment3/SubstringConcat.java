package com.assessment3;
import java.util.*;

public class SubstringConcat {
	    public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);

	        System.out.println("Enter a string:");
	        String str = sc.nextLine();

	        String result = "";

	        if (str.length() >= 2) {
	            result = str.substring(0, 2);
	        } 
	        else if (str.length() == 1) {
	            result = str + "@";
	        } 
	        else {
	            result = "@@";
	        }

	        System.out.println(result);

	        sc.close();
	    }
	}


