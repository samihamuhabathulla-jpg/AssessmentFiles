package com.assessment3;
	import java.io.*;
	import java.util.*;

	public class WordFrequency {
		    public static void main(String[] args) {

		        Scanner sc = new Scanner(System.in);

		        Map<String, Integer> map = new HashMap<>();

		        System.out.println("Enter number of lines:");
		        int n = sc.nextInt();
		        sc.nextLine(); 

		        System.out.println("Enter the lines:");

		        for (int i = 0; i < n; i++) {
		            String line = sc.nextLine();

		            String[] words = line.split(" ");

		            for (String word : words) {
		                word = word.toLowerCase();

		                if (map.containsKey(word)) {
		                    map.put(word, map.get(word) + 1);
		                } else {
		                    map.put(word, 1);
		                }
		            }
		        }

		        TreeMap<String, Integer> sortedMap = new TreeMap<>(map);
		        
		        for (String key : sortedMap.keySet()) {
		            System.out.println(key + ": " + sortedMap.get(key));
		        }

		        System.out.println("Unique words: " + map.size());

		        sc.close();
		    }
		}