package Assessment_2;
import java.util.Scanner;

class Customer{
	int id;
	String name;
	char gender;
	
	Customer(int id, String name, char gender){
		this.id=id;
		this.name=name;
		this.gender=gender;
	}
	int getId() {
		return id;
	}
	String getName() {
		return name;
	}
	char getGender() {
		return gender;
	}

public String toString() {
	return name+"(" + id + ")";
}}
class Account{
	int id;
	Customer customer;
	double balance;
	Account(int id, Customer customer){
		this.id=id;
		this.customer=customer;
		balance=0.0;
	}
	
	int getId() {
		return id;
	}
	Customer getCustomer() {
		return customer;
	}
	double getBalance() {
		return balance;
	}
	void deposit(double amount) {
		balance = balance +amount;
		System.out.println("AMOUNT DEPOSITED SUCCESFULLY!!");
	}
	void withdraw(double amount) {
		if(balance>=amount) {
			balance=balance-amount;
			System.out.println("AMOUNT WITHDRAWN SUCCESSFULLY!!");
		}
		else {
			System.out.println("AMOUNT WITHDRAWN EXCEEDS THE CURRENT BALANCE!");
        
		}
	}
}

public class CustomerAccount {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		
		Customer c = new Customer(901233,"PETER",'M');
		Account a = new Account(3456,c);
		
		System.out.println("ACCOUNT DETAILS");
        System.out.println("ACCOUNT_ID " + a.getId());
        System.out.println("CUSTOMER_ID " + c.getId());
        System.out.println("CUSTOMER_NAME : " + c.getName());
        System.out.println("CUSTOMER_GENDER : " + c.getGender());
        System.out.println("ACCOUNT_BALANCE : " + a.getBalance());
     }

}
