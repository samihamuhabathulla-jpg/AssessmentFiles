package Assessment_2;

		abstract class Product
		{
		    int productId;
		    String productName;
		    double price;

		    Product(int id, String name, double p)
		    {
		        productId = id;
		        productName = name;
		        price = p;
		    }

		    abstract void displayInfo();
		}

		class ElectronicProduct extends Product
		{
		    int warranty;

		    ElectronicProduct(int id, String name, double p, int w)
		    {
		        super(id, name, p);
		        warranty = w;
		    }

		    void displayInfo()
		    {
		        System.out.println("ELECTRONIC PRODUCT INFORMATION:");
		        System.out.println("ProductId : " + productId);
		        System.out.println("ProductName : " + productName);
		        System.out.println("Price : $" + price);
		        System.out.println("Warranty Period : " + warranty + " Months");
		        System.out.println();
		    }
		}

		class ClothingProduct extends Product
		{
		    String size;
		    String material;

		    ClothingProduct(int id, String name, double p, String s, String m)
		    {
		        super(id, name, p);
		        size = s;
		        material = m;
		    }

		    void displayInfo()
		    {
		        System.out.println("CLOTHING PRODUCT INFORMATION:");
		        System.out.println("ProductId : " + productId);
		        System.out.println("ProductName : " + productName);
		        System.out.println("Price : $" + price);
		        System.out.println("Size : " + size);
		        System.out.println("Material : " + material);
		        System.out.println();
		    }
		}

		public class Products {
		
		    public static void main(String[] args)
		    {
		        ElectronicProduct e1 = new ElectronicProduct(201, "SmartPhone", 15000.0, 12);
		        ClothingProduct c1 = new ClothingProduct(301, "Jacket", 2500.0, "L", "Cotton");

		        e1.displayInfo();
		        c1.displayInfo();
		    }
		

	}


