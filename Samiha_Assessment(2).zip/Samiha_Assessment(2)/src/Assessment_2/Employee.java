package Assessment_2;
import java.util.Scanner;

class Employee1
{
    int id;
    String empName;
    String jobRole;
    double empSalary;

    Employee1(int id, String empName, String jobRole, double empSalary)
    {
        this.id = id;
        this.empName = empName;
        this.jobRole = jobRole;
        this.empSalary = empSalary;
    }

    void displayDetails()
    {
        System.out.println("Employee Id : " + id);
        System.out.println("Employee Name : " + empName);
        System.out.println("Employee Designation : " + jobRole);
        System.out.println("Employee Salary : " + empSalary);
    }

    void increaseSalary(double percent)
    {
        empSalary = empSalary + (empSalary * percent / 100);
        System.out.println("Updated Salary : " + empSalary);
    }

    void increaseSalary(double percent, double bonus)
    {
        empSalary = empSalary + (empSalary * percent / 100) + bonus;
        System.out.println("Updated Salary with Bonus : " + empSalary);
    }
}

public class Employee {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Employee ID : ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Employee Name : ");
        String name = sc.nextLine();

        System.out.print("Enter Employee Designation : ");
        String role = sc.nextLine();

        System.out.print("Enter Employee Salary : ");
        double salary = sc.nextDouble();

        Employee1 emp = new Employee1(id, name, role, salary);

        System.out.println("\nEmployee Details");
        emp.displayDetails();

        System.out.print("\nEnter Salary Increase Percentage : ");
        double percent = sc.nextDouble();
        emp.increaseSalary(percent);

        System.out.print("Enter Bonus Amount : ");
        double bonus = sc.nextDouble();
        emp.increaseSalary(percent, bonus);
    }
}
